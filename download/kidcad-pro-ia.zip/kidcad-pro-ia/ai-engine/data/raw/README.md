# data/raw

Donnees brutes : netlists KiCad (.net), fichiers .kicad_pcb, projets
d'interchange importes tels quels, sans transformation.
