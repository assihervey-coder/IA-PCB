# data/processed

Donnees pretraitees : boards/netlists normalises (dicts Python / JSON alignes
sur le contrat `shared/types/pcb.proto`), grilles d'observation pretes pour
l'entrainement.
