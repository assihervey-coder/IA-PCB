# data/augmentations

Variantes augmentees : translations/rotations de composants, pads deplaces,
nets ajoutes/supprimes - pour la robustesse des modeles RL.
